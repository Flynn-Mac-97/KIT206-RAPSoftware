﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace KIT206_Assignment_01 {
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application {
        //main function for initialising global variables
        public App() {
            var testingString = "Hello World";
        }
    }

}
